#include <cmath>                // d�clare sqrt
#include <ctime>						// time
#include <stdio.h>
#include "r250.h"

double f(double x) {
  // x doit �tre compris entre -1 et 1 
  return sqrt(1 - x*x);
}

bool lancer()
  // tirage d'un point dans le carr� [0,1[ X [0,1[
{

 	double u =dr250();
	double v =dr250();
	
    if (v <= f(u)) {
      return true;
    } else {
      return false;
    }
}

float calcul_aire(int n) {
  // �value l'aire sous f par une m�thode de Monte-Carlo
  int i, dedans;

  dedans = 0;
  for (i=0; i<n; i++) {
    if (lancer() == true) {
      dedans = dedans + 1;
    }
  }
  return float(dedans)/n;
}

int main() {
  // la fonction principale
  const int N = 100000000;
  float pi;
  
	r250_init(time(NULL));				// initialisation al�atoire de la graine
				
  pi = 4.0 * calcul_aire(N);
  printf("%1.60f\n ", pi);
  
  return 0;
}
